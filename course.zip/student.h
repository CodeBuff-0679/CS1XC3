/**
 *@file student.h
 *@author SHarmin Ahmed
 *@brief make a structure and define functions
 *@version 0.1
 *@date 2022-04-12
 *
 *@copyright Copyright (c) 2022
 *
*/

/**
 *@brief define a structure
 *
 *
*/
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 *@brief define some functions
 *
 *
*/
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
