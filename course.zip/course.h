/**
 *@file course.h
 *@author SHarmin Ahmed
 *@brief make a structure and define functions
 *@version 0.1
 *@date 2022-04-12
 *
 *@copyright Copyright (c) 2022
 *
*/
#include "student.h"
#include <stdbool.h>
 
/**
 *@brief define a structure
 *
 *
*/
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 *@brief define some functions
 *
 *
*/
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


